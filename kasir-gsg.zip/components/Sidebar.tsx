
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { HomeIcon, ShoppingCartIcon, ArchiveBoxIcon, DocumentChartBarIcon, ArrowLeftOnRectangleIcon, UserIcon, ChartPieIcon } from '@heroicons/react/24/outline';

interface SidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ sidebarOpen, setSidebarOpen }) => {
  const { logout, user } = useAppContext();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const navLinkClasses = "flex items-center px-4 py-3 text-gray-300 hover:bg-gray-700 hover:text-white rounded-md transition-colors duration-200";
  const activeNavLinkClasses = "bg-primary-600 text-white";

  return (
    <>
      <div className={`fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity lg:hidden ${sidebarOpen ? 'block' : 'hidden'}`} onClick={() => setSidebarOpen(false)}></div>
      <div className={`fixed inset-y-0 left-0 z-30 w-64 bg-gray-900 transform transition-transform duration-300 lg:translate-x-0 lg:static lg:inset-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-center h-20 border-b border-gray-800">
          <h1 className="text-2xl font-bold text-white tracking-wider">KASIR GSG</h1>
        </div>
        <nav className="flex-1 px-4 py-6">
          <NavLink to="/" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`} end>
            <HomeIcon className="h-6 w-6 mr-3" />
            Dashboard
          </NavLink>
          <NavLink to="/pos" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>
            <ShoppingCartIcon className="h-6 w-6 mr-3" />
            Point of Sale
          </NavLink>
          <NavLink to="/products" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>
            <ArchiveBoxIcon className="h-6 w-6 mr-3" />
            Products
          </NavLink>
          <NavLink to="/transactions" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>
            <DocumentChartBarIcon className="h-6 w-6 mr-3" />
            Transactions
          </NavLink>
           <NavLink to="/reports" className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}>
            <ChartPieIcon className="h-6 w-6 mr-3" />
            Reports
          </NavLink>

          <div className="absolute bottom-0 w-full left-0 p-4 border-t border-gray-800">
             <div className="flex items-center mb-4 px-2">
                <UserIcon className="h-8 w-8 text-gray-400 mr-3" />
                <div>
                  <p className="text-white font-semibold">{user?.username}</p>
                  <p className="text-gray-400 text-sm capitalize">{user?.role}</p>
                </div>
              </div>
            <button onClick={handleLogout} className="w-full flex items-center justify-center px-4 py-3 text-gray-300 hover:bg-red-600 hover:text-white rounded-md transition-colors duration-200">
              <ArrowLeftOnRectangleIcon className="h-6 w-6 mr-3" />
              Logout
            </button>
          </div>
        </nav>
      </div>
    </>
  );
};

export default Sidebar;
