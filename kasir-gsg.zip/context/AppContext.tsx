
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { User, Product, CartItem, Transaction, PaymentMethod, StockLog, UserRole } from '../types';
import { mockUsers, mockProducts, mockTransactions, mockStockLogs } from '../data/mockData';
import { useNavigate } from 'react-router-dom';

interface AppContextType {
  user: User | null;
  users: User[];
  products: Product[];
  cart: CartItem[];
  transactions: Transaction[];
  stockLogs: StockLog[];
  login: (username: string, password_hash: string) => boolean;
  logout: () => void;
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateCartQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  completeTransaction: (paymentMethod: PaymentMethod) => Transaction | null;
  updateProduct: (productId: number, updatedData: Partial<Product>) => void;
  addUser: (username: string, password_hash: string) => void;
  addProduct: (product: Omit<Product, 'id' | 'imageUrl'>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = sessionStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions);
  const [stockLogs, setStockLogs] = useState<StockLog[]>(mockStockLogs);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      sessionStorage.setItem('user', JSON.stringify(user));
    } else {
      sessionStorage.removeItem('user');
    }
  }, [user]);

  const login = (username: string, password_hash: string): boolean => {
    // In a real app, you would verify the hash. Here we do a simple check.
    const foundUser = users.find(u => u.username === username && u.passwordHash === password_hash);
    if (foundUser) {
      setUser(foundUser);
      navigate('/');
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    setCart([]);
    navigate('/login');
  };

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.productId === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.productId === product.id
            ? { ...item, quantity: Math.min(product.stock, item.quantity + quantity) }
            : item
        );
      }
      return [...prevCart, { productId: product.id, quantity, price: product.sellingPrice, name: product.name }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.productId !== productId));
  };

  const updateCartQuantity = (productId: number, quantity: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    setCart(prevCart =>
      prevCart.map(item =>
        item.productId === productId
          ? { ...item, quantity: Math.max(0, Math.min(product.stock, quantity)) }
          : item
      )
    );
  };
  
  const clearCart = () => {
    setCart([]);
  };

  const updateProduct = (productId: number, updatedData: Partial<Product>) => {
    const originalProduct = products.find(p => p.id === productId);
    if (!originalProduct || !user) return;

    // Check if stock is changing to create a log
    if (updatedData.stock !== undefined && updatedData.stock !== originalProduct.stock) {
      const change = updatedData.stock - originalProduct.stock;
      const newLog: StockLog = {
        id: stockLogs.length + 1,
        productId,
        change,
        reason: 'Product details updated',
        timestamp: new Date().toISOString(),
        userId: user.id,
      };
      setStockLogs(prev => [newLog, ...prev]);
    }

    setProducts(prevProducts =>
      prevProducts.map(p =>
        p.id === productId ? { ...p, ...updatedData } : p
      )
    );
  };

  const completeTransaction = (paymentMethod: PaymentMethod): Transaction | null => {
    if (cart.length === 0 || !user) return null;

    let total = 0;
    let profit = 0;

    const transactionItems = cart.map(cartItem => {
      const product = products.find(p => p.id === cartItem.productId);
      if (!product) throw new Error("Product not found");
      
      total += cartItem.quantity * product.sellingPrice;
      profit += cartItem.quantity * (product.sellingPrice - product.purchasePrice);
      
      return {
        productId: product.id,
        quantity: cartItem.quantity,
        purchasePrice: product.purchasePrice,
        sellingPrice: product.sellingPrice,
      };
    });

    // Update stock
    setProducts(prevProducts => {
      const updatedProducts = [...prevProducts];
      const newStockLogs: StockLog[] = [];
      
      cart.forEach(cartItem => {
        const productIndex = updatedProducts.findIndex(p => p.id === cartItem.productId);
        if (productIndex !== -1) {
          const oldStock = updatedProducts[productIndex].stock;
          updatedProducts[productIndex].stock -= cartItem.quantity;
          
          newStockLogs.push({
            id: stockLogs.length + newStockLogs.length + 1,
            productId: cartItem.productId,
            change: -cartItem.quantity,
            reason: `Sale (TXN #${transactions.length + 1})`,
            timestamp: new Date().toISOString(),
            userId: user.id
          });
        }
      });
      
      setStockLogs(prev => [...newStockLogs.reverse(), ...prev]);
      return updatedProducts;
    });

    const newTransaction: Transaction = {
      id: `TXN-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: user.id,
      items: transactionItems,
      total,
      paymentMethod,
      profit
    };

    setTransactions(prev => [newTransaction, ...prev]);
    clearCart();
    return newTransaction;
  };
  
  const addUser = (username: string, password_hash: string) => {
    const newUser: User = {
        id: users.length + 1,
        username,
        passwordHash: password_hash,
        role: UserRole.Cashier
    };
    setUsers(prev => [...prev, newUser]);
  };

  const addProduct = (product: Omit<Product, 'id' | 'imageUrl'>) => {
    const newProduct: Product = {
      ...product,
      id: products.length + 1,
      imageUrl: `https://picsum.photos/seed/${products.length + 1}/400/300`,
    };
    setProducts(prev => [newProduct, ...prev]);
    if(user && product.stock > 0){
        const originalProduct = products.find(p => p.id === newProduct.id) || { stock: 0 };
        const change = product.stock - originalProduct.stock;
         const newLog: StockLog = {
            id: stockLogs.length + 1,
            productId: newProduct.id,
            change: change,
            reason: "Initial stock",
            timestamp: new Date().toISOString(),
            userId: user.id,
        };
        setStockLogs(prev => [newLog, ...prev]);
    }
  };


  return (
    <AppContext.Provider value={{
      user, users, products, cart, transactions, stockLogs,
      login, logout, addToCart, removeFromCart, updateCartQuantity, clearCart, 
      completeTransaction, updateProduct, addUser, addProduct
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
