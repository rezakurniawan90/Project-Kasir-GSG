import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { Transaction } from '../types';
import { XMarkIcon } from '@heroicons/react/24/solid';

const TransactionsPage: React.FC = () => {
    const { transactions, users } = useAppContext();
    const [filterDate, setFilterDate] = useState('');
    const [filterCashier, setFilterCashier] = useState('');
    const [selectedTxn, setSelectedTxn] = useState<Transaction | null>(null);

    const filteredTransactions = useMemo(() => {
        return transactions.filter(txn => {
            const dateMatch = filterDate ? txn.timestamp.startsWith(filterDate) : true;
            const cashierMatch = filterCashier ? txn.userId === parseInt(filterCashier) : true;
            return dateMatch && cashierMatch;
        });
    }, [transactions, filterDate, filterCashier]);

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Riwayat Transaksi</h1>
            <div className="flex flex-wrap gap-4 mb-4 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                <div>
                    <label htmlFor="dateFilter" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Filter Tanggal</label>
                    <input type="date" id="dateFilter" value={filterDate} onChange={e => setFilterDate(e.target.value)} className="mt-1 p-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md" />
                </div>
                <div>
                    <label htmlFor="cashierFilter" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Filter Kasir</label>
                    <select id="cashierFilter" value={filterCashier} onChange={e => setFilterCashier(e.target.value)} className="mt-1 p-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md">
                        <option value="">Semua Kasir</option>
                        {users.map(user => <option key={user.id} value={user.id}>{user.username}</option>)}
                    </select>
                </div>
            </div>

             <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">ID Transaksi</th>
                            <th scope="col" className="px-6 py-3">Tanggal</th>
                            <th scope="col" className="px-6 py-3">Kasir</th>
                            <th scope="col" className="px-6 py-3">Total</th>
                            <th scope="col" className="px-6 py-3">Pembayaran</th>
                            <th scope="col" className="px-6 py-3">Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTransactions.map(txn => (
                            <tr key={txn.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                <td className="px-6 py-4">{txn.id}</td>
                                <td className="px-6 py-4">{new Date(txn.timestamp).toLocaleString('id-ID')}</td>
                                <td className="px-6 py-4">{users.find(u => u.id === txn.userId)?.username}</td>
                                <td className="px-6 py-4 font-bold">{formatCurrency(txn.total)}</td>
                                <td className="px-6 py-4 capitalize">{txn.paymentMethod}</td>
                                <td className="px-6 py-4">
                                    <button onClick={() => setSelectedTxn(txn)} className="font-medium text-primary-600 dark:text-primary-500 hover:underline">Lihat</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {selectedTxn && <TransactionDetailModal transaction={selectedTxn} onClose={() => setSelectedTxn(null)} />}
        </div>
    );
};

const TransactionDetailModal: React.FC<{ transaction: Transaction, onClose: () => void }> = ({ transaction, onClose }) => {
    const { products, users } = useAppContext();
    const cashier = users.find(u => u.id === transaction.userId);

    const onPrint = () => {
        window.print();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-sm max-h-[90vh] flex flex-col">
                <div className="p-4 flex justify-between items-center border-b dark:border-gray-700">
                     <h3 className="text-lg font-bold">Struk Pembayaran</h3>
                     <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><XMarkIcon className="w-6 h-6"/></button>
                </div>
                <div id="receipt-content" className="p-6 overflow-y-auto text-sm text-gray-800 dark:text-gray-200">
                    <div className="text-center mb-4">
                        <h2 className="text-xl font-bold">KASIR GSG</h2>
                        <p>Jl. Merdeka No. 123, Jakarta</p>
                    </div>
                    <div className="border-t border-b border-dashed border-gray-400 dark:border-gray-600 py-2 mb-4">
                        <div className="flex justify-between"><span>No. Transaksi:</span><span>{transaction.id}</span></div>
                        <div className="flex justify-between"><span>Tanggal:</span><span>{new Date(transaction.timestamp).toLocaleString('id-ID')}</span></div>
                        <div className="flex justify-between"><span>Kasir:</span><span>{cashier?.username}</span></div>
                    </div>
                    <div>
                        {transaction.items.map(item => {
                            const product = products.find(p => p.id === item.productId);
                            return (
                                <div key={item.productId} className="flex justify-between mb-1">
                                    <div>
                                        <p>{product?.name}</p>
                                        <p className="text-gray-500">{item.quantity} x {formatCurrency(item.sellingPrice)}</p>
                                    </div>
                                    <p>{formatCurrency(item.quantity * item.sellingPrice)}</p>
                                </div>
                            );
                        })}
                    </div>
                     <div className="border-t border-dashed border-gray-400 dark:border-gray-600 mt-4 pt-2">
                        <div className="flex justify-between font-bold"><span>TOTAL</span><span>{formatCurrency(transaction.total)}</span></div>
                        <div className="flex justify-between"><span>Bayar ({transaction.paymentMethod})</span><span>{formatCurrency(transaction.total)}</span></div>
                     </div>
                     <p className="text-center mt-6">Terima Kasih!</p>
                </div>
                <div className="p-4 border-t dark:border-gray-700 flex gap-2">
                    <button onClick={onPrint} className="flex-1 bg-primary-600 text-white font-bold py-2 px-4 rounded-md hover:bg-primary-700 transition-colors">Cetak Ulang</button>
                    <button onClick={onClose} className="flex-1 bg-gray-200 dark:bg-gray-600 font-bold py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors">Tutup</button>
                </div>
            </div>
             <style>
                {`
                @media print {
                    body * {
                        visibility: hidden;
                    }
                    #receipt-content, #receipt-content * {
                        visibility: visible;
                    }
                    #receipt-content {
                        position: absolute;
                        left: 0;
                        top: 0;
                        width: 100%;
                        color: black !important;
                    }
                }
                `}
            </style>
        </div>
    )
}

export default TransactionsPage;