
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { Product, StockLog, UserRole } from '../types';
import { PencilIcon, PlusIcon, XMarkIcon, ClockIcon } from '@heroicons/react/24/solid';

const ProductsPage: React.FC = () => {
    const { products, user } = useAppContext();
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
    const [isEditModalOpen, setEditModalOpen] = useState(false);
    const [isAddProductModalOpen, setAddProductModalOpen] = useState(false);
    const [isHistoryModalOpen, setHistoryModalOpen] = useState(false);

    const filteredProducts = useMemo(() => {
        return products.filter(p =>
            p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            p.category.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [products, searchTerm]);

    const openEditModal = (product: Product) => {
        setSelectedProduct(product);
        setEditModalOpen(true);
    };

    const openHistoryModal = (product: Product) => {
        setSelectedProduct(product);
        setHistoryModalOpen(true);
    }

    const openAddProductModal = () => {
        setAddProductModalOpen(true);
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Manajemen Produk</h1>
                {user?.role === UserRole.Admin && (
                    <button onClick={openAddProductModal} className="flex items-center bg-primary-600 text-white font-bold py-2 px-4 rounded-md hover:bg-primary-700 transition-colors">
                        <PlusIcon className="w-5 h-5 mr-2" />
                        Tambah Produk
                    </button>
                )}
            </div>
            <div className="mb-4">
                <input
                    type="text"
                    placeholder="Cari produk..."
                    className="w-full max-w-md p-2 bg-white dark:bg-gray-800 rounded-md border border-gray-300 dark:border-gray-600 focus:ring-primary-500 focus:border-primary-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Nama Produk</th>
                            <th scope="col" className="px-6 py-3">Kategori</th>
                            <th scope="col" className="px-6 py-3">Harga Beli</th>
                            <th scope="col" className="px-6 py-3">Harga Jual</th>
                            <th scope="col" className="px-6 py-3">Stok</th>
                            <th scope="col" className="px-6 py-3 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredProducts.map(product => (
                            <tr key={product.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                    {product.name}
                                </th>
                                <td className="px-6 py-4">{product.category}</td>
                                <td className="px-6 py-4">{formatCurrency(product.purchasePrice)}</td>
                                <td className="px-6 py-4">{formatCurrency(product.sellingPrice)}</td>
                                <td className={`px-6 py-4 font-bold ${product.stock <= product.minStock ? 'text-yellow-500' : ''}`}>
                                    {product.stock}
                                </td>
                                <td className="px-6 py-4 text-center space-x-2">
                                    {user?.role === UserRole.Admin && (
                                        <button onClick={() => openEditModal(product)} className="font-medium text-primary-600 dark:text-primary-500 hover:underline">
                                           <PencilIcon className="w-5 h-5 inline-block"/> Edit
                                        </button>
                                    )}
                                    <button onClick={() => openHistoryModal(product)} className="font-medium text-green-600 dark:text-green-500 hover:underline">
                                        <ClockIcon className="w-5 h-5 inline-block"/> Riwayat
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isEditModalOpen && selectedProduct && (
                <ProductEditModal product={selectedProduct} onClose={() => setEditModalOpen(false)} />
            )}
            {isAddProductModalOpen && (
                <AddProductModal onClose={() => setAddProductModalOpen(false)} />
            )}
            {isHistoryModalOpen && selectedProduct && (
                <StockHistoryModal product={selectedProduct} onClose={() => setHistoryModalOpen(false)} />
            )}
        </div>
    );
};

// Modal components
const ProductEditModal: React.FC<{ product: Product, onClose: () => void }> = ({ product, onClose }) => {
    const { updateProduct } = useAppContext();
    const [formData, setFormData] = useState<Product>(product);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'number' ? parseFloat(value) || 0 : value
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        updateProduct(product.id, formData);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg">
                <div className="p-4 flex justify-between items-center border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">Edit Produk: {product.name}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><XMarkIcon className="w-6 h-6" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Nama Produk</label>
                        <input id="name" name="name" type="text" value={formData.name} onChange={handleChange} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                    </div>
                     <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Kategori</label>
                        <input id="category" name="category" type="text" value={formData.category} onChange={handleChange} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                    </div>
                    <div>
                        <label htmlFor="purchasePrice" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Harga Beli</label>
                        <input id="purchasePrice" name="purchasePrice" type="number" value={formData.purchasePrice} onChange={handleChange} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                    </div>
                     <div>
                        <label htmlFor="sellingPrice" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Harga Jual</label>
                        <input id="sellingPrice" name="sellingPrice" type="number" value={formData.sellingPrice} onChange={handleChange} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                    </div>
                    <div>
                        <label htmlFor="stock" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Stok</label>
                        <input id="stock" name="stock" type="number" value={formData.stock} onChange={handleChange} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                    </div>
                     <div>
                        <label htmlFor="minStock" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Stok Minimal</label>
                        <input id="minStock" name="minStock" type="number" value={formData.minStock} onChange={handleChange} required className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                    </div>

                    <div className="md:col-span-2 flex justify-end gap-2 pt-4">
                        <button type="button" onClick={onClose} className="py-2 px-4 bg-gray-200 dark:bg-gray-600 font-bold rounded-md hover:bg-gray-300 dark:hover:bg-gray-500">Batal</button>
                        <button type="submit" className="py-2 px-4 bg-primary-600 text-white font-bold rounded-md hover:bg-primary-700">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const AddProductModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
    const { addProduct } = useAppContext();
    const [formState, setFormState] = useState({
        name: '',
        category: '',
        barcode: '',
        purchasePrice: 0,
        sellingPrice: 0,
        stock: 0,
        minStock: 10
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value, type } = e.target;
        setFormState(prev => ({
            ...prev,
            [name]: type === 'number' ? parseFloat(value) : value
        }));
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addProduct(formState);
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-lg">
                <div className="p-4 flex justify-between items-center border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">Tambah Produk Baru</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><XMarkIcon className="w-6 h-6" /></button>
                </div>
                <form onSubmit={handleSubmit} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    {Object.keys(formState).map(key => (
                         <div key={key}>
                            <label htmlFor={key} className="block text-sm font-medium text-gray-700 dark:text-gray-300 capitalize">{key.replace(/([A-Z])/g, ' $1')}</label>
                            <input 
                                id={key} 
                                name={key}
                                type={typeof (formState as any)[key] === 'number' ? 'number' : 'text'} 
                                value={(formState as any)[key]} 
                                onChange={handleChange} 
                                required 
                                className="mt-1 block w-full border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500" />
                        </div>
                    ))}
                    <div className="md:col-span-2 flex justify-end gap-2 pt-4">
                        <button type="button" onClick={onClose} className="py-2 px-4 bg-gray-200 dark:bg-gray-600 font-bold rounded-md hover:bg-gray-300 dark:hover:bg-gray-500">Batal</button>
                        <button type="submit" className="py-2 px-4 bg-primary-600 text-white font-bold rounded-md hover:bg-primary-700">Tambah</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const StockHistoryModal: React.FC<{product: Product, onClose: () => void}> = ({product, onClose}) => {
    const { stockLogs, users } = useAppContext();
    const productLogs = stockLogs.filter(log => log.productId === product.id);

    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
                <div className="p-4 flex justify-between items-center border-b dark:border-gray-700">
                    <h3 className="text-lg font-bold">Riwayat Stok: {product.name}</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><XMarkIcon className="w-6 h-6" /></button>
                </div>
                <div className="p-6 overflow-y-auto">
                    {productLogs.length === 0 ? <p>Tidak ada riwayat.</p> : (
                        <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <tr>
                                    <th className="px-4 py-2">Tanggal</th>
                                    <th className="px-4 py-2">Perubahan</th>
                                    <th className="px-4 py-2">Alasan</th>
                                    <th className="px-4 py-2">User</th>
                                </tr>
                            </thead>
                             <tbody>
                                {productLogs.map(log => (
                                    <tr key={log.id} className="border-b dark:border-gray-700">
                                        <td className="px-4 py-2">{new Date(log.timestamp).toLocaleString('id-ID')}</td>
                                        <td className={`px-4 py-2 font-bold ${log.change > 0 ? 'text-green-500' : 'text-red-500'}`}>{log.change > 0 ? `+${log.change}`: log.change}</td>
                                        <td className="px-4 py-2">{log.reason}</td>
                                        <td className="px-4 py-2">{users.find(u => u.id === log.userId)?.username}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
                <div className="p-4 border-t dark:border-gray-700 flex justify-end">
                    <button onClick={onClose} className="bg-gray-200 dark:bg-gray-600 font-bold py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors">Tutup</button>
                </div>
            </div>
        </div>
    )
}


export default ProductsPage;
