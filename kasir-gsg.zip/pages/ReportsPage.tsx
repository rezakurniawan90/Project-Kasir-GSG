
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { Transaction } from '../types';
import { generateAiSummary } from '../services/geminiService';
import { SparklesIcon } from '@heroicons/react/24/solid';

type ReportPeriod = 'daily' | 'weekly' | 'monthly';

const ReportsPage: React.FC = () => {
    const { transactions, products } = useAppContext();
    const [period, setPeriod] = useState<ReportPeriod>('daily');
    const [aiSummary, setAiSummary] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    
    const { reportData, totalSales, totalProfit, productSales } = useMemo(() => {
        const now = new Date();
        const filteredTransactions = transactions.filter(t => {
            const txDate = new Date(t.timestamp);
            if (period === 'daily') {
                return txDate.toDateString() === now.toDateString();
            }
            if (period === 'weekly') {
                const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
                return txDate >= weekStart;
            }
            if (period === 'monthly') {
                return txDate.getMonth() === now.getMonth() && txDate.getFullYear() === now.getFullYear();
            }
            return false;
        });

        const totalSales = filteredTransactions.reduce((sum, t) => sum + t.total, 0);
        const totalProfit = filteredTransactions.reduce((sum, t) => sum + t.profit, 0);
        
        const productSales: {[key: number]: {name: string, quantity: number, total: number}} = {};
        filteredTransactions.forEach(t => {
            t.items.forEach(item => {
                if(!productSales[item.productId]) {
                     productSales[item.productId] = { name: products.find(p=>p.id === item.productId)?.name || 'Unknown', quantity: 0, total: 0 };
                }
                productSales[item.productId].quantity += item.quantity;
                productSales[item.productId].total += item.quantity * item.sellingPrice;
            })
        });

        return { reportData: filteredTransactions, totalSales, totalProfit, productSales: Object.values(productSales).sort((a,b)=> b.quantity - a.quantity) };
    }, [transactions, products, period]);

    const handleGenerateSummary = async () => {
        setIsLoading(true);
        setAiSummary('');
        try {
            const summary = await generateAiSummary({
                period,
                totalSales,
                totalProfit,
                productSales,
                totalTransactions: reportData.length,
            });
            setAiSummary(summary);
        } catch (error) {
            console.error("Error generating AI summary:", error);
            setAiSummary("Gagal membuat ringkasan. Silakan coba lagi.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Laporan Penjualan</h1>
            
            <div className="flex justify-between items-center mb-4 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md">
                <div className="flex gap-2">
                    <button onClick={() => setPeriod('daily')} className={`px-4 py-2 rounded-md font-semibold ${period === 'daily' ? 'bg-primary-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>Harian</button>
                    <button onClick={() => setPeriod('weekly')} className={`px-4 py-2 rounded-md font-semibold ${period === 'weekly' ? 'bg-primary-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>Mingguan</button>
                    <button onClick={() => setPeriod('monthly')} className={`px-4 py-2 rounded-md font-semibold ${period === 'monthly' ? 'bg-primary-600 text-white' : 'bg-gray-200 dark:bg-gray-700'}`}>Bulanan</button>
                </div>
                 <div className="flex gap-4">
                    {/* Placeholder for Export buttons */}
                    <button className="px-4 py-2 rounded-md font-semibold bg-green-600 text-white hover:bg-green-700">Export Excel</button>
                    <button className="px-4 py-2 rounded-md font-semibold bg-red-600 text-white hover:bg-red-700">Export PDF</button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                    <h2 className="text-lg font-semibold text-gray-500 dark:text-gray-400">Total Penjualan</h2>
                    <p className="text-3xl font-bold text-gray-900 dark:text-white">{formatCurrency(totalSales)}</p>
                </div>
                <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                    <h2 className="text-lg font-semibold text-gray-500 dark:text-gray-400">Total Keuntungan (Profit)</h2>
                    <p className="text-3xl font-bold text-green-500">{formatCurrency(totalProfit)}</p>
                </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md mb-6">
                <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
                    <h2 className="text-xl font-bold">Ringkasan AI</h2>
                    <button onClick={handleGenerateSummary} disabled={isLoading} className="flex items-center bg-primary-600 text-white font-bold py-2 px-4 rounded-md hover:bg-primary-700 transition-colors disabled:bg-gray-500">
                       {isLoading ? 'Memuat...' : <><SparklesIcon className="w-5 h-5 mr-2" /> Buat Ringkasan</>}
                    </button>
                </div>
                <div className="p-6">
                    {isLoading && <p>Menganalisis data penjualan...</p>}
                    {aiSummary && <div className="prose dark:prose-invert max-w-none whitespace-pre-wrap">{aiSummary}</div>}
                    {!isLoading && !aiSummary && <p className="text-gray-500">Klik tombol untuk membuat ringkasan penjualan dengan AI.</p>}
                </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-x-auto">
                 <h2 className="text-xl font-bold p-4">Laporan per Produk</h2>
                <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" className="px-6 py-3">Nama Produk</th>
                            <th scope="col" className="px-6 py-3">Jumlah Terjual</th>
                            <th scope="col" className="px-6 py-3">Total Penjualan</th>
                        </tr>
                    </thead>
                    <tbody>
                        {productSales.map((p, index) => (
                            <tr key={index} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                               <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{p.name}</th>
                               <td className="px-6 py-4">{p.quantity}</td>
                               <td className="px-6 py-4">{formatCurrency(p.total)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

        </div>
    );
};

export default ReportsPage;
