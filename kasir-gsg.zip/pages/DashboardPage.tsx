
import React from 'react';
import { useAppContext } from '../context/AppContext';
import { formatCurrency } from '../utils/helpers';
import { ArchiveBoxIcon, ExclamationTriangleIcon, BanknotesIcon, ChartBarIcon } from '@heroicons/react/24/outline';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const StatCard: React.FC<{ icon: React.ReactNode; title: string; value: string; color: string }> = ({ icon, title, value, color }) => (
    <div className={`bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex items-center border-l-4 ${color}`}>
        <div className="mr-4">{icon}</div>
        <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
        </div>
    </div>
);

const DashboardPage: React.FC = () => {
    const { products, transactions } = useAppContext();

    const lowStockProducts = products.filter(p => p.stock <= p.minStock).length;
    
    const today = new Date().toISOString().split('T')[0];
    const todaysTransactions = transactions.filter(t => t.timestamp.startsWith(today));
    const salesToday = todaysTransactions.reduce((sum, t) => sum + t.total, 0);
    
    // Dummy data for chart
    const salesData = [
        { name: '00:00', sales: 0 },
        { name: '03:00', sales: 0 },
        { name: '06:00', sales: 0 },
        { name: '09:00', sales: todaysTransactions.filter(t => new Date(t.timestamp).getHours() < 9).reduce((acc, t) => acc + t.total, 0) },
        { name: '12:00', sales: todaysTransactions.filter(t => new Date(t.timestamp).getHours() < 12).reduce((acc, t) => acc + t.total, 0) },
        { name: '15:00', sales: todaysTransactions.filter(t => new Date(t.timestamp).getHours() < 15).reduce((acc, t) => acc + t.total, 0) },
        { name: '18:00', sales: todaysTransactions.filter(t => new Date(t.timestamp).getHours() < 18).reduce((acc, t) => acc + t.total, 0) },
        { name: '21:00', sales: salesToday },
    ];


    return (
        <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <StatCard 
                    icon={<ArchiveBoxIcon className="h-10 w-10 text-primary-500" />}
                    title="Total Products"
                    value={products.length.toString()}
                    color="border-primary-500"
                />
                <StatCard 
                    icon={<ExclamationTriangleIcon className={`h-10 w-10 ${lowStockProducts > 0 ? 'text-yellow-500' : 'text-green-500'}`} />}
                    title="Stock Menipis"
                    value={lowStockProducts.toString()}
                    color={lowStockProducts > 0 ? 'border-yellow-500' : 'border-green-500'}
                />
                <StatCard 
                    icon={<BanknotesIcon className="h-10 w-10 text-green-500" />}
                    title="Total Penjualan Hari Ini"
                    value={formatCurrency(salesToday)}
                    color="border-green-500"
                />
            </div>
            
            <div className="mt-8 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4 flex items-center">
                    <ChartBarIcon className="h-6 w-6 mr-2" />
                    Grafik Penjualan Hari Ini
                </h2>
                <div style={{ width: '100%', height: 300 }}>
                    <ResponsiveContainer>
                        <LineChart data={salesData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(100, 116, 139, 0.3)" />
                            <XAxis dataKey="name" stroke="rgb(100, 116, 139)" />
                            <YAxis stroke="rgb(100, 116, 139)" tickFormatter={(value) => formatCurrency(Number(value))}/>
                            <Tooltip
                                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '0.5rem' }}
                                labelStyle={{ color: '#e2e8f0' }}
                                itemStyle={{ color: '#3b82f6' }}
                                formatter={(value) => [formatCurrency(Number(value)), 'Sales']}
                            />
                            <Line type="monotone" dataKey="sales" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 8 }}/>
                        </LineChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    );
};

export default DashboardPage;
