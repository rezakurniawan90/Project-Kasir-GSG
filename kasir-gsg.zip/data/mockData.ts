
import { User, Product, Transaction, StockLog, UserRole, PaymentMethod } from '../types';

export const mockUsers: User[] = [
  { id: 1, username: 'admin', role: UserRole.Admin, passwordHash: 'admin123' },
  { id: 2, username: 'kasir1', role: UserRole.Cashier, passwordHash: 'kasir123' },
];

export const mockProducts: Product[] = [
  { id: 1, barcode: '8992761131015', name: 'Indomie Goreng', category: 'Instant Noodle', purchasePrice: 2500, sellingPrice: 3000, stock: 100, minStock: 20, imageUrl: 'https://picsum.photos/seed/1/400/300' },
  { id: 2, barcode: '8999909074026', name: 'Coca-Cola 390ml', category: 'Beverage', purchasePrice: 4000, sellingPrice: 5000, stock: 48, minStock: 12, imageUrl: 'https://picsum.photos/seed/2/400/300' },
  { id: 3, barcode: '8996001600213', name: 'Pocari Sweat 500ml', category: 'Beverage', purchasePrice: 5500, sellingPrice: 7000, stock: 15, minStock: 10, imageUrl: 'https://picsum.photos/seed/3/400/300' },
  { id: 4, barcode: '8886008101060', name: 'Chitato Sapi Panggang', category: 'Snack', purchasePrice: 8000, sellingPrice: 10000, stock: 30, minStock: 10, imageUrl: 'https://picsum.photos/seed/4/400/300' },
  { id: 5, barcode: '8998866102148', name: 'Teh Pucuk Harum 350ml', category: 'Beverage', purchasePrice: 2800, sellingPrice: 3500, stock: 80, minStock: 20, imageUrl: 'https://picsum.photos/seed/5/400/300' },
  { id: 6, barcode: '8992741951006', name: 'Aqua 600ml', category: 'Beverage', purchasePrice: 2000, sellingPrice: 3000, stock: 150, minStock: 30, imageUrl: 'https://picsum.photos/seed/6/400/300' },
];

export const mockStockLogs: StockLog[] = [
    {id: 1, productId: 1, change: 100, reason: "Initial stock", timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), userId: 1},
    {id: 2, productId: 2, change: 48, reason: "Initial stock", timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), userId: 1},
    {id: 3, productId: 3, change: 25, reason: "Initial stock", timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), userId: 1},
    {id: 4, productId: 4, change: 30, reason: "Initial stock", timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), userId: 1},
    {id: 5, productId: 5, change: 80, reason: "Initial stock", timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), userId: 1},
    {id: 6, productId: 6, change: 150, reason: "Initial stock", timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), userId: 1},
    {id: 7, productId: 3, change: -10, reason: "Sale (TXN #1)", timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), userId: 2},
];

export const mockTransactions: Transaction[] = [
    {
        id: 'TXN-1678886400000',
        timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        userId: 2,
        items: [
            { productId: 3, quantity: 10, purchasePrice: 5500, sellingPrice: 7000 },
        ],
        total: 70000,
        paymentMethod: PaymentMethod.Cash,
        profit: 15000,
    },
     {
        id: 'TXN-1678972800000',
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        userId: 2,
        items: [
            { productId: 1, quantity: 5, purchasePrice: 2500, sellingPrice: 3000 },
            { productId: 2, quantity: 2, purchasePrice: 4000, sellingPrice: 5000 },
        ],
        total: 25000,
        paymentMethod: PaymentMethod.EWallet,
        profit: 4500,
    }
];
