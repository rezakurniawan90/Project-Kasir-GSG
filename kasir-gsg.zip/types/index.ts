
export enum UserRole {
  Admin = 'admin',
  Cashier = 'cashier',
}

export interface User {
  id: number;
  username: string;
  role: UserRole;
  passwordHash: string;
}

export interface Product {
  id: number;
  barcode: string;
  name: string;
  category: string;
  purchasePrice: number;
  sellingPrice: number;
  stock: number;
  minStock: number;
  imageUrl: string;
}

export interface StockLog {
  id: number;
  productId: number;
  change: number;
  reason: string;
  timestamp: string;
  userId: number;
}

export interface CartItem {
  productId: number;
  quantity: number;
  price: number;
  name: string;
}

export enum PaymentMethod {
  Cash = 'cash',
  Transfer = 'transfer',
  EWallet = 'e-wallet',
}

export interface TransactionItem {
  productId: number;
  quantity: number;
  purchasePrice: number;
  sellingPrice: number;
}

export interface Transaction {
  id: string;
  timestamp: string;
  userId: number;
  items: TransactionItem[];
  total: number;
  paymentMethod: PaymentMethod;
  profit: number;
}
