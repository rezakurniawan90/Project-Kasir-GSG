
import { GoogleGenAI } from "@google/genai";
import { formatCurrency } from "../utils/helpers";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This will prevent the app from crashing if API_KEY is not set.
  // The UI will handle the error gracefully.
  console.warn("Gemini API key not found. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

interface ReportData {
  period: string;
  totalSales: number;
  totalProfit: number;
  totalTransactions: number;
  productSales: {
    name: string;
    quantity: number;
    total: number;
  }[];
}

export const generateAiSummary = async (data: ReportData): Promise<string> => {
    if (!API_KEY) {
        return "Fitur AI dinonaktifkan karena API Key tidak ditemukan. Mohon konfigurasikan environment variable API_KEY.";
    }

    const model = 'gemini-2.5-flash';
    
    const topProducts = data.productSales.slice(0, 5).map(p => `- ${p.name}: ${p.quantity} unit terjual (${formatCurrency(p.total)})`).join('\n');

    const prompt = `
    Anda adalah seorang analis bisnis ahli untuk sebuah toko ritel. Buatlah ringkasan singkat dan wawasan (insight) dari data penjualan berikut.
    Gunakan format laporan yang jelas, singkat, dan mudah dimengerti dengan poin-poin.
    Bahasa: Indonesia.

    Data Penjualan:
    - Periode Laporan: ${data.period}
    - Total Transaksi: ${data.totalTransactions}
    - Total Penjualan: ${formatCurrency(data.totalSales)}
    - Total Keuntungan (Profit): ${formatCurrency(data.totalProfit)}
    - Produk Terlaris (Top 5):
    ${topProducts || 'Tidak ada produk terjual.'}

    Ringkasan Laporan:
    - **Performa Umum:** (Beri komentar tentang performa penjualan secara keseluruhan).
    - **Produk Unggulan:** (Sebutkan produk yang paling laku dan kontribusinya).
    - **Wawasan & Rekomendasi:** (Berikan 1-2 saran actionable berdasarkan data, misalnya tentang stok produk terlaris atau promosi).
    `;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Gemini API call failed:", error);
        throw new Error("Failed to generate summary from AI.");
    }
};
